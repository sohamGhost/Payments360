package com.fiserv.payment360.repositories;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

//import com.fiserv.payment360.entity.UserBankAccountEntity;
import com.fiserv.payment360.entity.UserProfileEntity;
@Repository
public interface UserProfileRepository extends JpaRepository<UserProfileEntity, Integer>{
	public interface UserBankRepository extends JpaRepository<UserBankRepository, Integer>{
		
	}
}
