package com.fiserv.payment360.util;

import java.time.LocalDateTime;

public class Test {
	
	public static void main (String [] args) {
		LocalDateTime ldt = LocalDateTime.now();
		System.out.println(ldt);
	}

}
