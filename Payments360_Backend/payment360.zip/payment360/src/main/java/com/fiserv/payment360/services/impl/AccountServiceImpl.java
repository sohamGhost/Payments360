package com.fiserv.payment360.services.impl;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fiserv.payment360.entity.AccountStatusEntity;
import com.fiserv.payment360.entity.AccountTypeEntity;
import com.fiserv.payment360.repository.AccountStatusRepository;
import com.fiserv.payment360.repository.AccountTypeRepository;
import com.fiserv.payment360.services.iface.IAccountService;

/**
 * 
 * @author 2136526
 *
 */

@Service
public class AccountServiceImpl implements IAccountService {

	private static final Logger log = LoggerFactory.getLogger(AccountServiceImpl.class);

	@Autowired
	AccountStatusRepository accountStatusRepo;

	@Autowired
	AccountTypeRepository accountTypeRepo;

	/**
	 * 
	 */
	@Override
	public String getAccountStatusById(Integer accountId) throws Exception {

		final String METHOD = "getAccountStatusById() ";

		log.info(METHOD + "Entry -> accountId:: " + accountId);

		String status = "UNKNOWN";

		Optional<AccountStatusEntity> opt = accountStatusRepo.findById(accountId);

		if (opt.isPresent()) {
			AccountStatusEntity record = opt.get();
			status = record.getAccountStatus();
		}

		log.info(METHOD + "Exit -> status:: " + status);
		return status;
	}

	/**
	 * 
	 */
	@Override
	public String getAccountTypeById(Integer accountId) throws Exception {

		final String METHOD = "getAccountTypeById() ";

		log.info(METHOD + "Entry -> accountId:: " + accountId);

		String type = "UNKNOWN";

		Optional<AccountTypeEntity> opt = accountTypeRepo.findById(accountId);

		if (opt.isPresent()) {
			AccountTypeEntity record = opt.get();
			type = record.getAccountType();
		}

		log.info(METHOD + "Exit -> type:: " + type);
		return type;
	}

}
