package com.fiserv.payment360.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fiserv.payment360.entity.AccountTypeEntity;

public interface AccountTypeRepository extends JpaRepository<AccountTypeEntity, Integer> {

}
