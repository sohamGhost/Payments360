package com.fiserv.payment360.util;

public class P360Constants {
	
	
	
	public static final String USER_PROFILE_DETAILS_URL = "/userProfile/details/{userId}";
	public static final String USER_PROFILE_UPDATE_URL = "/userProfile/userAgreement";
	public static final String UPDATED_BY = "SYSTEM";

}
