package com.fiserv.payment360.services.iface;

import com.fiserv.payment360.model.ContentDetails;

public interface IContentManagementService {
	
	public ContentDetails fetchContent(String type) throws Exception;

}
