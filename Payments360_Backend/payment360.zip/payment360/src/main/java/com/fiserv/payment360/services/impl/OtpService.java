package com.fiserv.payment360.services.impl;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Description;
import org.springframework.stereotype.Service;

import com.fiserv.payment360.helper.OtpGenerator;
import com.fiserv.payment360.model.OtpToken;
import com.fiserv.payment360.entity.*;
import com.fiserv.payment360.repository.*;


@Description(value = "Service responsible for handling OTP related functionality.")
@Service
public class OtpService {

	private final Logger LOGGER = LoggerFactory.getLogger(OtpService.class);

	@Autowired
	private OtpGenerator otpGenerator;
	
	//creating function to get user name
	@Autowired
	private UserProfileRepository userprofileentityrepository;

	private UserProfileEntity entity;
	public String getUserNameById(int userId) {
		entity=userprofileentityrepository.findById(userId)
				.orElseThrow(()->new RuntimeException("User not found with ID:"+userId));
		return entity.getUserName();
		
	}
	
	

	/**
	 * Method for generate OTP number
	 *
	 * @param key - provided key (username in this case)
	 * @return boolean value (true|false)
	 */
	public OtpToken generateOtp(String key) {

		Integer otpValue = -1;
		OtpToken token = new OtpToken();
		// generate otp
		otpValue = otpGenerator.generateOTP(key);
		if (otpValue == -1) {
			LOGGER.error("OTP generator is not working...");

		} else {
			LOGGER.info("Generated OTP: {}", otpValue);
		}

		// Setting the OTP value in response DTO - OtpToken
		token.setUserName(key);
		token.setOtp(otpValue);
		token.setBlnValidateFlag(false);

		return token;

	}

	/**
	 * Method for validating provided OTP
	 *
	 * @param key       - provided key
	 * @param otpNumber - provided OTP number
	 * @return boolean validateFlag (true|false)
	 */
	public OtpToken validateOTP(OtpToken token) {

		Boolean validateFlag = false;
		// get OTP from cache
		Integer cacheOTP = otpGenerator.getOPTByKey(token.getUserName());
		if (cacheOTP != null && cacheOTP.equals(token.getOtp())) {
			otpGenerator.clearOTPFromCache(token.getUserName());
			validateFlag = true;
		}

		// Set the validation flag in the OTP token
		token.setBlnValidateFlag(validateFlag);

		return token;
	}


}

