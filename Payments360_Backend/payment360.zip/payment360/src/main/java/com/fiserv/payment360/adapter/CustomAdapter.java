package com.fiserv.payment360.adapter;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.fiserv.payment360.entity.UserProfileEntity;
import com.fiserv.payment360.model.Account;
import com.fiserv.payment360.model.UserProfileResponse;

@Component
public class CustomAdapter {

	public UserProfileResponse convertEntityToDto(UserProfileEntity entity) {

		UserProfileResponse user = new UserProfileResponse();
		List<Account> accounts = new ArrayList<>();

		// USER_PROFILE
		user.setUserId(entity.getUserId());
		user.setFirstName(entity.getFirstName());
		// Get the values from Entity and set them in the DTO

		// USER_BANK_ACCOUNT
		entity.getUserbankaccountentity().stream().forEach(acct -> {

			Account userAcct = new Account();
			userAcct.setAccountId(acct.getAccountId());
			// Get the values from Entity and set them in the DTO
			accounts.add(userAcct);
		});

		user.setAccounts(accounts);

		return user;

	}

}
