package com.fiserv.payment360.model;

import java.io.Serializable;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import io.swagger.v3.oas.annotations.media.Schema;

public class UserProfileUpdateReq implements Serializable {

	private static final long serialVersionUID = 1L;

	@Schema(name = "userId", description = "UserId of profile", type = "Integer", minimum = "1", maximum = "10", example = "01")
	@NotBlank(message = "The associate Id is required.")
	@Size(min = 1, max = 10, message = "The length of userId Id must be between 5 and 30 characters")
	private Integer userId;

	@Schema(name = "accountId", description = "AccountId of profile", type = "Integer", minimum = "1", maximum = "10", example = "01")
	@NotBlank(message = "The associate Id is required.")
	@Size(min = 1, max = 10, message = "The length of account Id must be between 1 and 10 characters")
	private Integer accountId;

	@Schema(name = "userconsent", description = "userconsent of profile", type = "String", minimum = "1", maximum = "5", example = "Y")
	@NotBlank(message = "The userconsent is required.")
	@Size(min = 1, max = 5, message = "The length of userconsent must be between 1 and 5 characters")
	private String userConsent;

	@Schema(name = "smsconsent", description = "smsconsent of profile", type = "String", minimum = "1", maximum = "5", example = "Y")
	@NotBlank(message = "The smsconsent is required.")
	@Size(min = 1, max = 5, message = "The length of smsconsent must be between 1 and 5 characters")
	private String smsConsent;

	@Schema(name = "preferred", description = "userconsent of profile", type = "String", minimum = "1", maximum = "5", example = "Y")
	@NotBlank(message = "The preferred is required.")
	@Size(min = 1, max = 5, message = "The length of preferred must be between 1 and 5 characters")
	private String preferred;

	public UserProfileUpdateReq() {

	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public Integer getAccountId() {
		return accountId;
	}

	public void setAccountId(Integer accountId) {
		this.accountId = accountId;
	}

	public String getUserConsent() {
		return userConsent;
	}

	public void setUserConsent(String userConsent) {
		this.userConsent = userConsent;
	}

	public String getSmsConsent() {
		return smsConsent;
	}

	public void setSmsConsent(String smsConsent) {
		this.smsConsent = smsConsent;
	}

	public String getPreferred() {
		return preferred;
	}

	public void setPreferred(String preferred) {
		this.preferred = preferred;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("UserProfileUpdateReq [userId=");
		builder.append(userId);
		builder.append(", accountId=");
		builder.append(accountId);
		builder.append(", userConsent=");
		builder.append(userConsent);
		builder.append(", smsConsent=");
		builder.append(smsConsent);
		builder.append(", preferred=");
		builder.append(preferred);
		builder.append("]");
		return builder.toString();
	}

}
