package com.fiserv.payment360.config;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.ResourcePatternResolver;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fiserv.payment360.model.ContentDetails;
import com.fiserv.payment360.model.ContentConfig;

@Configuration
public class ContentLoader {

	private final Logger logger = LoggerFactory.getLogger(ContentLoader.class);

	private Map<String, ContentDetails> contentDefMap = new HashMap<>();

	@Value("${verbiage.config.file}")
	private String configFile;

	@Autowired
	ObjectMapper objectMapper;

	@Autowired
	ResourcePatternResolver resourceResolver;

	@PostConstruct
	public void init() throws IOException {

		// Call method - getFileFromResource -- will return a list
		try {

			List<String> result = getFileFromResource(configFile);
			result.stream().forEach(file -> {
				System.out.println("file:: " + file);
				ContentConfig contentConfig;
				try {
					/* objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES); */
					/* contentConfig=objectMapper.readValue(file, ContentConfig.class); */
					ClassLoader classLoader = this.getClass().getClassLoader();

					contentConfig = objectMapper.readValue(classLoader.getResourceAsStream("json/" + file),
							ContentConfig.class);

					List<ContentDetails> contents = contentConfig.getContents();

					if (contents != null && contents.size() > 0) {
						contentDefMap = contents.stream().collect(Collectors.toMap(ContentDetails::getType, c -> c));
					} else {
						logger.error("No contents available...");
						
					}

					contentDefMap.forEach((k, v) -> System.out.println("Key:" + k + ", Value: " + v));
				} catch (JsonMappingException jme) {
					logger.error("JsonMappingException occurred:: " + jme.getMessage());
				} catch (JsonProcessingException jpe) {
					logger.error("JsonMappingException occurred:: " + jpe.getMessage());
				} catch (IOException ioe) {
					logger.error("JsonMappingException occurred:: " + ioe.getMessage());
				}

			});

			// Loop through the list

			// Use objectMapper to map the file to the ContentConfig object

			// Loop through the contentConfig -> List<Content> - set it to contentDefMap - >
			// key = type; value = content object
		} catch (final Exception e) {
			e.printStackTrace();
		}

	}

	public ContentDetails getVerbiageConfig(String type) {
		return contentDefMap.get(type);
	}

	private List<String> getFileFromResource(String folder) throws IOException {

		List<String> result = new ArrayList<>();
		// Use resourceResolver here
		Resource[] resources = resourceResolver.getResources(folder);
		for (Resource res : resources) {
			result.add(res.getFilename());
		}

		return result;

	}

}
