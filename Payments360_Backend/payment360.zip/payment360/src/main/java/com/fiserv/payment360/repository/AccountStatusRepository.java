package com.fiserv.payment360.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fiserv.payment360.entity.AccountStatusEntity;

public interface AccountStatusRepository extends JpaRepository<AccountStatusEntity, Integer> {

}
