package com.fiserv.payment360.services.iface;

public interface IAccountService {
	
	public String getAccountStatusById(Integer accountId) throws Exception;
	public String getAccountTypeById(Integer accountId) throws Exception;

}
