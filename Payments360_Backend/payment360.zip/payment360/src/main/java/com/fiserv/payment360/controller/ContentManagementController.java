package com.fiserv.payment360.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fiserv.payment360.exception.ApiError;
import com.fiserv.payment360.exception.ResourceNotFoundException;
import com.fiserv.payment360.model.ContentDetails;
import com.fiserv.payment360.services.iface.IContentManagementService;

/*import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
*/
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping
@Tag(name = "Content Management", description = "Content management APIs")
public class ContentManagementController {

	private final Logger logger = LoggerFactory.getLogger(ContentManagementController.class);

	@Autowired
	IContentManagementService contentMgmtService;

	@Operation(summary = "Retrieve a user profile by Id", description = "Get a User profile object by specifying its id.", tags = { "Content Management" })
	@ApiResponses({ @ApiResponse(responseCode = "200", content = {
			@Content(schema = @Schema(implementation = ContentDetails.class), mediaType = "application/json") }),
			@ApiResponse(responseCode = "400", description = "BAD REQUEST", content = {
					@Content(schema = @Schema(implementation = ApiError.class)) }),
			@ApiResponse(responseCode = "500", description = "INTERNAL SERVER ERROR", content = {
					@Content(schema = @Schema(implementation = ApiError.class)) }) })
	@GetMapping(value = "/content-management", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ContentDetails> getContentVerbiage(@RequestParam(name = "type") String type)
			throws Exception {

		try {
			final String METHOD = "getContentVerbiage() ";

			logger.info(METHOD + " type:: " + type);

			ContentDetails content = contentMgmtService.fetchContent(type);
			if (content != null) {
				return new ResponseEntity<ContentDetails>(content, HttpStatus.OK);
			} else {
				throw new ResourceNotFoundException("No content found for - " + type);
			}
		} catch (Exception ex) {
			logger.error("Exception occurred:: " + ex.getMessage());
			throw ex;
		}

	}
}
