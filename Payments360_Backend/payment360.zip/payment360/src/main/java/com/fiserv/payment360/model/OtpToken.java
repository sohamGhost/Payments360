package com.fiserv.payment360.model;

import java.io.Serializable;

/**
 * 
 */

public class OtpToken {

	private static final long serialVersionUID = 1L;
	private String userName;
	private Integer otp;
	private Boolean blnValidateFlag;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public Integer getOtp() {
		return otp;
	}

	public void setOtp(Integer otp) {
		this.otp = otp;
	}

	public Boolean getBlnValidateFlag() {
		return blnValidateFlag;
	}

	public void setBlnValidateFlag(Boolean blnValidateFlag) {
		this.blnValidateFlag = blnValidateFlag;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("OtpToken [userName=");
		builder.append(userName);
		builder.append(", otp=");
		builder.append(otp);
		builder.append(", blnValidateFlag=");
		builder.append(blnValidateFlag);
		builder.append("]");
		return builder.toString();
	}


}
