package com.fiserv.payment360.services.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fiserv.payment360.config.ContentLoader;
import com.fiserv.payment360.model.ContentDetails;
import com.fiserv.payment360.services.iface.IContentManagementService;

@Service
public class ContentManagementServiceImpl implements IContentManagementService {
	
	@Autowired
	ContentLoader loader;

	@Override
	public ContentDetails fetchContent(String type) throws Exception {
		
		ContentDetails content = loader.getVerbiageConfig(type);
		
		return content;
	}

}
