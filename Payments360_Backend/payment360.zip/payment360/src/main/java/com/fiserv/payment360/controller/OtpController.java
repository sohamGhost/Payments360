package com.fiserv.payment360.controller;

//import com.starter.springboot.services.OtpService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fiserv.payment360.exception.ResourceNotFoundException;

import com.fiserv.payment360.model.OtpToken;
import com.fiserv.payment360.services.impl.OtpService;

import javax.validation.Valid;

@RestController
@RequestMapping("/auth")

public class OtpController {
	private final Logger log = LoggerFactory.getLogger(OtpController.class);

	@Autowired
	private OtpService otpService;

	@GetMapping(value = "/otp/{userId}")
	public ResponseEntity<OtpToken> getOTP(@PathVariable int userId) throws Exception{
		try {
		log.debug("userId: {}", userId);
		OtpToken token = new OtpToken();
		String userName = "";

		// TODO - Fetch the username from USER_PROFILE table here and pass it as an input
		userName=otpService.getUserNameById(userId);
		// parameter in generateOtp() method

		// Call your service method here -
		token = otpService.generateOtp(userName);
		if(userName!=null) {

		return new ResponseEntity<>(token, HttpStatus.OK);
		}else {
			throw new ResourceNotFoundException("No username found for - " +userId);
		}
		
		}
		catch(Exception ex){
			log.error("Exception occured:: "+ ex.getMessage());
			throw ex;
		}
	}

	@PostMapping(value = "/otpVerification")
	public ResponseEntity<OtpToken> verifyOtp(@Valid @RequestBody OtpToken verifyTokenRequest)  {
		String username = verifyTokenRequest.getUserName();
		Integer otp = verifyTokenRequest.getOtp();

		verifyTokenRequest = otpService.validateOTP(verifyTokenRequest);
		if (!verifyTokenRequest.getBlnValidateFlag()) {
			return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
		}
		

		return new ResponseEntity<>(verifyTokenRequest, HttpStatus.OK);
	}
}
