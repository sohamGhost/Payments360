package com.fiserv.payment360.model;

import java.util.List;

public class ContentConfig {

	public ContentConfig() {

	}

	private List<ContentDetails> contents;

	public List<ContentDetails> getContents() {
		return contents;
	}

	public void setContents(List<ContentDetails> contents) {
		this.contents = contents;
	}

}
