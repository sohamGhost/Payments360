package com.fiserv.payment360.model;

public class ContentDetails {

	private String type;
	private String verbiage;

	public ContentDetails() {

	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getVerbiage() {
		return verbiage;
	}

	public void setVerbiage(String verbiage) {
		this.verbiage = verbiage;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Content [type=");
		builder.append(type);
		builder.append(", verbiage=");
		builder.append(verbiage);
		builder.append("]");
		return builder.toString();
	}

}
