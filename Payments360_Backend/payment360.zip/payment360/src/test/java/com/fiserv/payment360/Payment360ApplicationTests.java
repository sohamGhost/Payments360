package com.fiserv.payment360;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.apache.tomcat.jni.User;
import org.aspectj.lang.annotation.Before;
//import org.junit.jupiter.api.ClassOrderer.OrderAnnotation;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.WebApplicationContext;

import com.fiserv.payment360.controller.UserProfileController;
import com.fiserv.payment360.entity.UserBankAccountEntity;
import com.fiserv.payment360.entity.UserProfileEntity;
import com.fiserv.payment360.repository.UserProfileRepository;
import com.fiserv.payment360.services.impl.UserProfileServiceImpl;

//@Runwith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
@Transactional
@TestMethodOrder(OrderAnnotation.class)
public class Payment360ApplicationTests {
	
	@Autowired
	private UserProfileController userProfileController;
	
	@Autowired
	private UserProfileServiceImpl userProfileImpl;
	
	@Autowired 
	private UserProfileEntity userProfileEntity;
	
	@Test
	@Order(1)
	void checkCreateUserProfile() {
		
		userProfileEntity=new UserProfileEntity(1,1,1,"575747465453454",)
		
		userProfileController = new UserProfileController(9, "johnkumardoe123", "john", "kumar","doe","johndoe@gmail.com","7895678456","dtfdtr","Y","null","null","LocalDateTime.now()"
				,"System",LocalDateTime.now(),"System",userProfileEntity.getUserBankAccountEntity());
		
		ResponseEntity<?> response1 = userProfileController.getUserProfileById(1);
		assertEquals(HttpStatus.CREATED, response1.getStatusCode());
		
		ResponseEntity<?> response2 = userProfileController.getUserProfileById(1);
		assertEquals(HttpStatus.CONFLICT, response2.getStatusCode());
	}


}
